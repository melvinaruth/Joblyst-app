package com.example.joblystapp.data

data class SignUpResult(
    val data: UserData?,
    val errorMessage: String?
)
